import 'package:flutter_course/scopedModels/connectedAlbumsModel.dart';
import 'package:scoped_model/scoped_model.dart';

import '../domain/user.dart';

mixin UtilityModel on ConnectedAlbumsModel {

}