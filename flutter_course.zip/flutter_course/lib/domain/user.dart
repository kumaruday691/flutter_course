import 'package:flutter/material.dart';

class User {

  String id;
  String email;
  String token;

  User({@required this.id, @required this.email, @required this.token});

}